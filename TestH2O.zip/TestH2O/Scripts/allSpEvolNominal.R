# Plot all molar fractions on 2 graphs (neutrals,ions) for nominal run
# Calculates some nominal indicators 

# Start 
# setwd('..')
PRINT=TRUE

# Load sample files
files = list.files(path="./MC_Output",pattern="fracmol_",full.names=TRUE)
x = read.table(files[1], header=TRUE, skip=0)
time= x[-1,1]
y   = x[-1,-1]
y=y/y[,'N2']

# Species list
line  = readLines(con=files[1], n=1)
species = scan(text=line, what=character(), 
               strip.white=TRUE, quiet=TRUE)[-1]
nsp= length(species)
nt = length(time)
# names(y)=species

ions=grepl("\\+$",species)
ions = ions | species == 'E'

cat('Conso CH4 (%)',100*(y[1,'CH4']-y[length(time),'CH4'])/y[1,'CH4'],'\n')
cat('Ionization ratio',y[nt,'E'],'\n')

if(PRINT) pdf(file=paste('allSpEvolNominal.pdf',sep=''),
              width=12,height=9)
par(mar=c(4,4,1,4))
matplot(time,y[,!ions],log='xy',type='l', yaxs='i',xlim=c(1e-3,max(time)),
        lwd=1,lty=1,col=(1:nsp)[!ions],ylim=c(1e-6,1e-1))
grid()
mtext(species[!ions],side=4,outer=FALSE,at=y[nt,!ions],
      srt=90,cex=0.75,las=2,line=0.5,padj=1,
      col=(1:nsp)[!ions])

# sp='C2H6'; lines(time,y[,sp],lwd=5)

par(mar=c(4,4,1,4))
matplot(time,y[,ions],log='xy',type='l', yaxs='i',xlim=c(1e-3,max(time)),
        lwd=1,lty=1,col=(1:nsp)[ions],ylim=c(1e-12,y[nt,'E']))
grid()
mtext(species[ions],side=4,outer=FALSE,at=y[nt,ions],
      srt=90,cex=0.75,las=2,line=0.5,padj=1,
      col=(1:nsp)[ions])
sp='E'; lines(time,y[,sp],lwd=5)
if(PRINT)  dev.off()


