#!/bin/bash

# Clean results repository
rm MC_Output/*

for ((i=0;i<=$1;i++)) 
do 
  Scripts/OneRun_Loc.sh $i 
done


