#!/bin/bash -x

echo `hostname`

ORIG='/homes/pernot/TestLethe'

cd $TMPDIR

# Get general data and code
scp -r $PBS_SERVER:$ORIG/Run/* .

# Get specific data for this run
printf -v NUM4 "%04d" $NUM
echo $NUM4
scp $PBS_SERVER:$ORIG/MC_Input/Reactions/run_${NUM4}.csv ./reac_params.dat
scp $PBS_SERVER:$ORIG/MC_Input/Photoprocs/${NUM4}_*.dat ./Photo/
cd ./Photo
for f in ${NUM4}_*.dat; do mv "$f" "$(echo $f | sed s/${NUM4}_// )"; done 
cd -

# Run code
./reactor

# Save results
scp ./fracmol_out.dat  $PBS_SERVER:$ORIG/MC_Output/fracmol_${NUM4}.dat
scp ./rrates.out       $PBS_SERVER:$ORIG/MC_Output/reacs_rates_${NUM4}.dat
scp ./phrates.out      $PBS_SERVER:$ORIG/MC_Output/photo_rates_${NUM4}.dat
