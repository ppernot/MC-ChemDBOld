require("compiler",quietly=TRUE); enableJIT(3)
require(RColorBrewer,quietly=TRUE)
library(fields)
library('CHNOSZ')
data('thermo')

bordersCx = function (spList) {
  # Plot borders of Cx blocks in a mole fractions correlation matrix
  # ordered neutrals/ions
  ions   = grepl("\\+$",spList)
  neus   = !ions
  spN    = spList[neus]
  compo  = t(sapply(spN,get.atoms))
  nHeavy = compo[,1]+compo[,3]
  minH   = min(nHeavy)
  maxH   = max(nHeavy)
  for (x in minH:maxH) {
    lim=range(which(nHeavy==x))
    rect(lim[1]-0.5,lim[1]-0.5,
         lim[2]+0.5,lim[2]+0.5,
         border='darkgreen',lwd=3)
    text(lim[1],lim[2],x,cex=3,pos=1,offset=-2,col='darkgreen')
  }  
  spI    = spList[ions]
  compo  = t(sapply(spI,get.atoms))
  nHeavy = compo[,1]+compo[,3]
  minH   = min(nHeavy)
  maxH   = max(nHeavy)
  for (x in minH:maxH) {
    lim=range(which(nHeavy==x))+length(spN)
    rect(lim[1]-0.5,lim[1]-0.5,
         lim[2]+0.5,lim[2]+0.5,
         border='purple',lwd=3)   
    text(lim[1],lim[2],x,cex=3,pos=1,offset=-2,col='purple')
  }  
}
calcAtoms = function(formula) {
  atoms=i2A(formula)
  nC = tryCatch(atoms[1,'C'],error= function(x) 0)
  nH = tryCatch(atoms[1,'H'],error= function(x) 0)
  nN = tryCatch(atoms[1,'N'],error= function(x) 0)
  c(nC,nH,nN)
}
get.atoms <- function (sp) {
  sp1=sub('l-','',sub('c-','',sp))
  sp1=sub('^X','',sp1)
  sp1=sub('^1','',sp1)
  sp1=sub('^3','',sp1)
  sp1=sub('N4S','N',sp1)
  sp1=sub('N2D','N',sp1)
  sp1=sub('\\(.*\\)','',sp1)
  tryCatch(calcAtoms(sp1),error= function(x) NA)
}
massCxHyNz = function(sto) sto[1]*12.0107 + sto[2]*1.00794 + sto[3]*14.00674
ionCrossSec = function (sto) sto[1]*0.46 + sto[2]*1.086 + sto[3]*1.384

# Robust Correlation coefficients
# library(WGCNA)
# allowWGCNAThreads()
# library(flashClust)

# Start #####
PRINT=TRUE
case='Apsis'

# Load yMean, ySd and species
load(file=paste('yStats_',case,'.Rda',sep=''))
yMean[is.nan(yMean)]=-50
ySd[is.nan(ySd)]=0

# Stoechiometry
compo = t(sapply(species,get.atoms))
mass  = apply(compo,1,massCxHyNz)
crSec = apply(compo,1,ionCrossSec)

orderByMass=order(mass)
species=species[orderByMass]
mass=mass[orderByMass]
compo=compo[orderByMass,]

azot=grepl("N",species)
neus= ! grepl("\\+$",species) #& !azot
nNeus= sum(neus)
listNeus=species[neus]
massNeus=mass[neus]
yMean=yMean[neus]
ySd=ySd[neus]
crSec=crSec[neus]


tabFrag=matrix(0,nrow=nNeus,ncol=10+max(mass))
msBase='~/Tests/Pampre/MS_reference/NIST.msp'
dBase=readLines(msBase)
for (isp in 1:nNeus) {
  lines = dBase %in% paste('Formula: ',listNeus[isp],sep='')
  nLines = sum(lines)
  if(nLines !=0) {
    print(paste(listNeus[isp],':',nLines))
    for (iLine in 1:nLines) {
      iFrag=which(lines)[iLine]+2
      frag = matrix(scan(text=dBase[iFrag]),nrow=2,byrow=FALSE)
      tabFrag[isp,frag[1,]] = tabFrag[isp,frag[1,]] + frag[2,]
    }
    tabFrag[isp,]=tabFrag[isp,]/sum(tabFrag[isp,])*crSec[isp]/crSec['N2']
  }
}
rownames(tabFrag)=listNeus

# Build MS & MS components
MS  = matrix(0,nrow=nNeus,ncol=10+max(mass))
MSG = matrix(0,nrow=nNeus,ncol=10+max(mass))
mxMass = 80
thresh =-15
icol=0
labels=c()
for (isp in 1:nNeus) {
  if(yMean[isp] >= thresh) {
    icol=icol+1
    labels[icol]=listNeus[isp]
    MS[icol,]  = tabFrag[isp,]*10^yMean[isp]
    sdMS = log(10)*MS[icol,]*ySd[isp]
    if(icol==1) {
      MSG[icol,] = MS[icol,]
      FMSG = sdMS^2
    } else {
      MSG[icol,] = MSG[icol-1,] + MS[icol,]
      FMSG = FMSG + sdMS^2
    }
  }
}
ncol=icol
FMSG=FMSG^0.5

# MAjor component of each peak
majors = apply(MS,2,which.max)
labView=labels[majors]

colors=brewer.pal(8,'Dark2')
colors=rep(colors,50)

minIntens=1e-8
maxIntens=1e-1
# MS
pdf(file=paste0('EI_MS_',case,'.pdf'),width=12,height=9)
par(mar=c(4,4,2,1),xaxs='i',xaxt='n',yaxt='s')
MSI=MSG[ncol,]
sel=MSI>minIntens
MSI[!sel]=NA

plot(1:mxMass,MSI[1:mxMass],type='n',
     log='y',ylim=c(minIntens,maxIntens),
     xlim=c(0,mxMass+1),xlab='m/z',ylab='Norm. intensity',
     main=case)
mtext(seq(0,mxMass,by=5),side=1,at=seq(0,mxMass,by=5))
grid(col='grey80')
segments(1:mxMass,MSI[1:mxMass]+2*FMSG[1:mxMass],
         1:mxMass,MSI[1:mxMass]-2*FMSG[1:mxMass],
         lwd=8,lend=2,col=colors[7])
points(1:mxMass,MSI[1:mxMass],pch=19,col=colors[8])
lines(1:mxMass,MSI[1:mxMass],lwd=2,type='h',col=colors[8])
text((1:mxMass)[sel],MSI[sel]+2*FMSG[sel],
     labels=paste0('--',labView[sel]),
     srt=90,cex=0.7,col=colors[2],adj=c(0,0.5,1))
dev.off()

# MS analysis
pdf(file=paste0('EI_MS_analysis_',case,'.pdf'),width=9,height=12)
par(fig=c(0.0,1.0,0.0,0.4),mar=c(4,4,0,5),xaxs='i',xaxt='n',yaxt='s')
plot(1:mxMass,1:mxMass,type='n',log='y',ylim=c(minIntens,maxIntens),
     xlim=c(0,mxMass+1),xlab='m/z',ylab='Norm. intensity')
mtext(seq(0,mxMass,by=5),side=1,at=seq(0,mxMass,by=5))
grid(col='grey80')
abline(v=1:mxMass,col='gray80')

for (icol in ncol:1) 
  lines((1:mxMass)[sel],MSG[icol,sel],type='h',
        col=colors[icol],lwd=8,lend=2)
text((1:mxMass)[sel],MSG[ncol,sel],
     labels=paste0('--',labView[sel]),
     srt=90,cex=0.7,col=colors[3],adj=c(0,0.5,1))


# legend('topright',legend=labels[1:ncol],col=colors,lwd=5)

MSI=t(apply(MS,1,function(x) x/MSG[ncol,]))
MSI[,!sel]=NA
MSI[MSI<1e-3]=0
selSp = rowSums(MSI,na.rm=TRUE) != 0
MSI=MSI[selSp,]
MSI[MSI<1e-3]=NA
nsel=sum(selSp)
# Weights by mass peak
MSI = MSI / colSums(MSI,na.rm=TRUE)[col(MSI)]

par(fig=c(0.0,1.0,0.4,1.0),mar=c(0,4,1,5),new=TRUE,xaxt='n',yaxt='n')
mypalette=brewer.pal(9,'Blues')
image(1:mxMass,1:nsel,t(MSI[1:nsel,1:mxMass]),col=mypalette,
      xlim=c(0,mxMass+1),xlab='',ylab='')
abline(h=1:nsel,col='gray80')
abline(v=1:mxMass,col='gray80')
image(1:mxMass,1:nsel,t(MSI[1:nsel,1:mxMass]),col=mypalette,
      add=TRUE)
mtext(labels[selSp],col=colors[selSp],side=2,at=1:nsel,
      las=2,adj=1,cex=0.8)
mtext(labels[selSp],col=colors[selSp],side=4,at=1:nsel,
      las=2,adj=0,cex=0.8)
mtext(seq(0,mxMass,by=5),side=3,at=seq(0,mxMass,by=5))

dev.off()
