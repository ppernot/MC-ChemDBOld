# Plot molar fraction MC samples for all species as f(time) 

# Load 1 sample files
files = list.files(path="./MC_Output",pattern="fracmol_",full.names=TRUE)
x = read.table(files[1], header=TRUE, skip=0)
time=x[-1,1]

# Species list
line  = readLines(con=files[1], n=1)
species = scan(text=line, what=character(), 
               strip.white=TRUE, quiet=TRUE)[-1]
iN2= which(species=="N2")

# Get all data
nf = length(files)
nsp= length(species)
nt = length(time)

conc=array(0,dim=c(nf,nt,nsp))
for(i in seq_along(files[1:nf]) ) {
  tab = read.table(files[i], header=TRUE, skip=0)
  time=tab[-1,1]
  y=as.matrix(tab[-1,-1])
  conc[i,1:nt,1:nsp] = y[1:nt,1:nsp] /sum(tab[iN2,])  
}

col = rgb(unlist(t(col2rgb("blue"))),alpha=12,maxColorValue = 255)

pdf(file=paste0('allSpEvolMC.pdf'),width=12,height=10)
for (show in species) {
  iShow= which(species==show)
  if (diff(range(conc[,,iShow])) != 0 ) {
    matplot(time,t(conc[1:nf,1:nt,iShow]),
            type='l',log='xy',col=col,lwd=5,lty=1,
            main=show,xlim=c(1e-10,1e4),ylim=c(1e-20,1))
    lines(time,t(conc[1,1:nt,iShow]),col='red',lty=1,lwd=3)
    grid()
  } 
}
dev.off()
