#=================================================#
# Beautify photorates output                      #
#=================================================#

reacs = readLines('photo_list.dat')
rates = signif(as.numeric(unlist(read.table('phrates.out'))),6)
df = data.frame(reacs,rates)
sink('photo_rates.out')
print(df,quote=TRUE)
sink()
