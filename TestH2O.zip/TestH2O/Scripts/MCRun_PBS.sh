#!/bin/bash

rm -f MC_Output/*

for ((i=1;i<=$1;i++)) 
do 
  sleep 0.35
  qsub -q vd@lethe -v NUM=$i Scripts/OneRun_PBS.sh 
done


